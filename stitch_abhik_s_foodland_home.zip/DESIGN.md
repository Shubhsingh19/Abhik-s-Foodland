```markdown
# Design System Strategy: The Culinary Editorial

This design system is a comprehensive framework designed to transform the digital presence of Abhik's Foodland into a high-end, editorial experience. It moves away from the cluttered, traditional "menu-board" aesthetic and embraces a philosophy of tonal depth, precise typography, and intentional negative space.

---

## 1. Overview & Creative North Star

### Creative North Star: "The Modern Maître D'"
The digital experience should feel as professional and curated as a high-end tasting menu. Our goal is **The Modern Maître D'**: a system that is authoritative yet welcoming, using "Soft Minimalism" to guide the user's eye toward the culinary artistry without the distraction of heavy UI containers.

**Breaking the Template:**
To avoid a generic look, we employ **Intentional Asymmetry**. Instead of a rigid 12-column grid, we utilize generous, uneven margins and overlapping imagery. High-contrast typography scales (pairing large, geometric headlines with compact, technical labels) create a rhythm that feels more like a premium magazine than a standard website.

---

## 2. Colors

The palette is a sophisticated extraction of the food itself—charcoal embers, rich ambers, and deep organic oranges—set against a clean, "paper-white" surface.

### Tonal Strategy
- **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. Differentiation between sections must be achieved through background shifts. For example, a `surface` section transitions into a `surface-container-low` section to denote a change in content without visual noise.
- **Surface Hierarchy & Nesting:** Treat the UI as physical layers of fine paper. Use `surface-container-lowest` for the most elevated elements (like a floating cart or a featured dish card) sitting atop a `surface-container` background.
- **The "Glass & Gradient" Rule:** Floating navigation and modal overlays should utilize **Glassmorphism**. Apply `surface` with 80% opacity and a `20px` backdrop-blur to allow the rich food imagery to bleed through softly.
- **Signature Textures:** For primary CTAs and Hero backgrounds, use a subtle linear gradient from `primary` (#ad2c00) to `primary_container` (#d34011) at a 135-degree angle. This provides a "glow" that mimics warm restaurant lighting.

---

## 3. Typography

The typography strategy pairs technical precision with bold, geometric expression.

- **Display & Headlines (Space Grotesk):** This font provides a "developer-friendly" yet premium feel. Use `display-lg` for hero statements. The wide apertures and geometric shapes convey modern professionalism.
- **Body & Labels (Inter):** Inter is used for its exceptional readability. It acts as the "functional" counterpart to the expressive headlines.
- **Hierarchy as Identity:** Use `label-md` in all-caps with `0.05em` letter-spacing for category tags (e.g., "NON-VEG STARTER") to create an authoritative, architectural feel.

---

## 4. Elevation & Depth

We convey hierarchy through **Tonal Layering** rather than traditional drop shadows.

- **The Layering Principle:** Stacking tiers creates natural lift. 
  - *Base:* `surface`
  - *Section:* `surface-container-low`
  - *Card:* `surface-container-lowest`
- **Ambient Shadows:** If a floating effect is required (e.g., a "Reserve Now" button), use an extra-diffused shadow: `box-shadow: 0 12px 32px rgba(27, 28, 28, 0.06)`. The shadow color must be a tint of `on-surface` (#1b1c1c), never pure black.
- **The "Ghost Border" Fallback:** If a container requires definition against a similar background, use a **Ghost Border**: 1px solid `outline-variant` at 15% opacity.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `rounded-md` (0.375rem), `on-primary` text. No border.
- **Secondary:** `surface-container-highest` background with `on-surface` text.
- **Tertiary:** Transparent background, `primary` text, with a 1px `outline-variant` Ghost Border (20% opacity).

### Cards & Menu Items
**Strict Rule:** No dividers. Separate menu items using the Spacing Scale (use `6` or `2rem`). 
- **Layout:** Use an asymmetrical layout—image slightly overlapping the card boundary to create depth. 
- **Typography:** Use `title-md` for dish names and `body-sm` for descriptions.

### Chips (Food Categories)
- Use `rounded-full` (9999px).
- **Active State:** `secondary_container` background with `on_secondary_container` text.
- **Inactive State:** `surface-container-high` with `on_surface_variant` text.

### Inputs
- **Style:** Underline-only or subtle Ghost Border. 
- **Focus State:** Transition the underline to `primary` with a height of 2px. 
- **Typography:** Always use `label-md` for floating labels.

---

## 6. Do's and Don'ts

### Do
- **DO** use white space as a functional element. A "breathable" menu feels more expensive than a crowded one.
- **DO** use the Spacing Scale religiously. Consistent gaps (e.g., always `2rem` between items) create an invisible grid of professionalism.
- **DO** use high-quality, desaturated food photography that complements the `charcoal` and `amber` palette.
- **DO** use `secondary` (Amber) for accent elements like price tags or "Chef's Special" badges.

### Don't
- **DON'T** use 100% black. Use `on-surface` (#1b1c1c) for a softer, more editorial "charcoal" feel.
- **DON'T** use 1px solid dividers between menu items. Use the `surface-container` tiers to group related items instead.
- **DON'T** use harsh, small-radius corners. Stick to `md` (0.375rem) or `lg` (0.5rem) to maintain the "Soft Minimalist" aesthetic.
- **DON'T** use standard blue for links. All interactive elements should stem from the `primary` (Deep Orange) or `secondary` (Amber) tokens.

---

*This design system is a living document intended to guide the creation of a signature digital home for Abhik's Foodland. Every pixel must serve the purpose of clarity, elegance, and appetite.*```